#import my
from my import cal1,cal2

